export const environment = {
  production: true,
  api: 'http://localhost:3000',
  imagesPath: 'assets',
  name: 'Byte Bank Broker',
};
