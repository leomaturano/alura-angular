const acoesAPI = require("./acoes");
const userAPI = require("./user");
const portfolioAPI = require("./portfolio");

module.exports = { acoesAPI, userAPI, portfolioAPI };
