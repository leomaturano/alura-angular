const acoesRoutes = require("./acoes");
const portfolioRoutes = require("./portfolio");
const userRoutes = require("./user");

module.exports = { acoesRoutes, portfolioRoutes, userRoutes };
